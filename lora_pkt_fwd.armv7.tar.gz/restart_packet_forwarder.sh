#!/bin/bash

echo 'Package forwarder restart not yet implemented.';